//
//  ContentView.swift
//  SignInWithApple
//
//  Created by Ashish Viltoriya on 02/01/24.
//

import SwiftUI

struct ContentView: View {
    @State var name = ""
    @EnvironmentObject var authorizationStatus: UserSettings
    var body: some View {
        
        VStack {
            Button(action: {
                if self.name.isEmpty {
                    SignUpWithAppleView(name: $name)
                }
            }){
                HStack(spacing: 15) {
                    Image("apple")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 25, height: 25)
                        .padding(.leading, 85)
                    Text("Sign in with Apple")
                        .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))
                    Spacer()
                }}
            
            .modifier(SFButton())
            .background(Color.white)
            .cornerRadius(50.0)
            .padding(.bottom,0)
  
        }
        .padding()
        .background(Color.gray)
    }
        
        
}

#Preview {
    ContentView()
}
