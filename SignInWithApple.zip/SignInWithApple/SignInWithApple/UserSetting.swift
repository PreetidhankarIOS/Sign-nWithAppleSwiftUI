//
//  UserSetting.swift
//  SignInWithApple
//
//  Created by Ashish Viltoriya on 03/01/24.
//

import Foundation
class UserSettings: ObservableObject {
    // 1 = Authorized, -1 = Revoked
    @Published var authorization: Int = 0
    
    
}
