//
//  SignInWithAppleApp.swift
//  SignInWithApple
//
//  Created by Ashish Viltoriya on 02/01/24.
//

import SwiftUI

@main
struct SignInWithAppleApp: App {
    @AppStorage("token") var token: String?
  
    var body: some Scene {
        WindowGroup {
            if token != nil {
                HomeView()
            } else {
                ContentView()
            }
           
        }
    }
}
